<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

class mdl_recipient extends CI_Model {
 
	function __construct(){
		parent::__construct();
	}  
	// query search pegawai
	function form_get_all($count,$offset,$perpage,$filter){
		$where = "where r.tipekeanggotaan='recipient' ";
		if(strlen($filter)>0){
			$where  .= "and r.namalengkap like '".$filter."%' ";
		}
		if($count){
			$query = "SELECT r.*,i.instansi,
					(SELECT telepon FROM telepon WHERE regid=r.regidrec ORDER BY urut ASC LIMIT 0,1 ) AS telepon,
					(SELECT email FROM daftaremail WHERE regid=r.regidrec ORDER BY urut ASC LIMIT 0,1 ) AS email
					FROM recipient r 
					left join instansi i on  i.kodeinstansi=r.kodeinstansi $where ";
		}else{
			$query = "SELECT r.*,i.instansi,
					(SELECT telepon FROM telepon WHERE regid=r.regidrec ORDER BY urut ASC LIMIT 0,1 ) AS telepon,
					(SELECT email FROM daftaremail WHERE regid=r.regidrec ORDER BY urut ASC LIMIT 0,1 ) AS email
				    FROM recipient r 
					left join instansi i on  i.kodeinstansi=r.kodeinstansi $where order by r.namalengkap asc limit $offset,$perpage";
		}
		 
		return $this->db->query($query);
	}
	function form_get_byid($kode){ 
		// $query = "Select *,date_format(tglmasukanggota,'%d-%m-%Y') as tglmasukanggotafrm,
		// 		  date_format(tanggallahir,'%d-%m-%Y') as tanggallahirfrm, date_format(tmtcpns,'%d-%m-%Y') as tmtcpnsfrm
		// 		  from recipient where regidrec=".$kode;
		$query = "SELECT regidrec,noanggota,DATE_FORMAT(tglmasukanggota,'%d-%m-%Y') AS tglmasukanggotafrm,namalengkap,panggilan,tempatlahir,
						DATE_FORMAT(tanggallahir,'%d-%m-%Y') AS tanggallahirfrm,jeniskelamin,alamat,usia,kodeagama,kodekelompok,kodeuniversitas,
						kodeinstitusi,jabatan,kodejenjang,fakultas,programstudi,jurusan,kodepekerjaan,kodeinstansi,sukubangsa,linkedin,website,
						fb,twitter,catatan,photoprofil,cvpath,tipekeanggotaan,ipk,nipbaru,niplama,gelardpn,gelarblk,kodepos,jns_kepeg,kodekedudukan,
						kodekawin,statuspeg,DATE_FORMAT(tmtcpns,'%d-%m-%Y') AS tmtcpnsfrm,DATE_FORMAT(tmtpns,'%d-%m-%Y') AS tmtpnsfrm,kodejenjangawl,
						kodejenjangakh,DATE_FORMAT(lulusawal,'%d-%m-%Y') AS lulusawalfrm,DATE_FORMAT(lulusakhir,'%d-%m-%Y') AS lulusakhirfrm,
						DATE_FORMAT(diklatstruktural1,'%d-%m-%Y') AS diklatstruktural1frm,DATE_FORMAT(diklatstruktural2,'%d-%m-%Y') AS diklatstruktural2frm,
						DATE_FORMAT(diklatstruktural3,'%d-%m-%Y') AS diklatstruktural3frm,DATE_FORMAT(diklatstruktural4,'%d-%m-%Y') AS diklatstruktural4frm,
						DATE_FORMAT(diklatstruktural5,'%d-%m-%Y') AS diklatstruktural5frm,unitorganisasi,kodejabatan,jabstruk,eseleon,
						DATE_FORMAT(tmteseleon,'%d-%m-%Y') AS tmteseleonfrm,jafung,DATE_FORMAT(tmtjafung,'%d-%m-%Y') AS tmtjafungfrm,jafungumum,
						DATE_FORMAT(tmtjafungumum,'%d-%m-%Y') AS tmtjafungumumfrm,golawal,DATE_FORMAT(tmtgolawal,'%d-%m-%Y') AS tmtgolawalfrm,golakhir,
						DATE_FORMAT(tmtgolakhir,'%d-%m-%Y') AS tmtgolakhirfrm,gajipokokbaru,nokarpeg,nokaris,noaktalahir,noaskes,notaspen,
						DATE_FORMAT(tglaktalahir,'%d-%m-%Y') AS tglaktalahirfrm,nonpwp,DATE_FORMAT(tglnpwp,'%d-%m-%Y') AS tglnpwpfrm,kodegoldar
				  from recipient where regidrec=".$kode;
		return $this->db->query($query);
	}
	function form_save($data,$kode){
		if($kode!=""){
			$this->db->where('regidrec', $kode);
			return $this->db->update('recipient', $data);
		}else{
			return $this->db->insert('recipient', $data);			 
		}
	}
	function update_profil_photo($kode,$filename){
		$this->db->where('regidrec', $kode);
		$data['photoprofil'] = $filename;
		return $this->db->update('recipient', $data);
	}
	function save_attachment($data){		
		return $this->db->insert('daftarattachment', $data);		
	}
	function update_cv($kode,$filename){
		$this->db->where('regidrec', $kode);
		$data['cvpath'] = $filename;
		return $this->db->update('recipient', $data);
	} 
	function form_delete($kode,$page){		
		$query = "delete from recipient where regidrec=".$kode;
		$aff =  $this->db->query($query);
		if($aff){
			$query = "delete from daftaremail where regid=".$kode." and page='".$page."'";
			$aff =  $this->db->query($query);
			if($aff){
				$query = "delete from telepon where regid=".$kode." and page='".$page."'";
				$aff =  $this->db->query($query);
			}
		}
		
		return $aff;
	}
	function generate_number($parsing){ 
		$query = "SELECT * FROM recipient 
				  WHERE tipekeanggotaan='recipient' and substring(noanggota,1,8)='".$parsing."'
				  ORDER BY regidrec DESC LIMIT 0 , 1";
		$rst = $this->db->query($query);
		if($rst->num_rows()>0){
			$newno = substr($rst->first_row()->noanggota,8,4)+1;
			$newno = str_pad($newno,4,"0",STR_PAD_LEFT); 
			return $newno;
		}else{
			return "0001";
		}
	}
}