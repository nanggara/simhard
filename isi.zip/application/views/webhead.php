	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>RSUD LANGSA | Database Pegawai</title>

     
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/custom.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/datepicker.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/inspinia/css/token-input-facebook.css" rel="stylesheet">
           
	<script src="<?php echo base_url();?>assets/themes/inspinia/js/jquery-1.10.2.js"></script>
	<script src="<?php echo base_url();?>assets/themes/inspinia/js/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url();?>assets/themes/inspinia/js/jquery.tokeninput.js"></script> 
	