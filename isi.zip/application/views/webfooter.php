
					
        <div class="footer"> 
            <div>
                <strong>Copyright</strong> Bahana Global Solution
            </div>
        </div>
	</div>
</div>
        
 <!-- Mainly scripts -->
    
    <script src="<?php echo base_url();?>assets/themes/inspinia/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/themes/inspinia/js/jquery.metisMenu.js"></script> 

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url();?>assets/themes/inspinia/js/inspinia.js"></script>
    <script src="<?php echo base_url();?>assets/themes/inspinia/js/pace.min.js"></script>
     
    <!-- iCheck -->
    <script src="<?php echo base_url();?>assets/themes/inspinia/js/icheck.min.js"></script> 
    
    <script> 
            $('#progressBar').hide(); 
    </script>