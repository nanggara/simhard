<div id="modal-progress" class="modal fade" aria-hidden="true">
	<div class="modal-dialog">  
		<div class="modal-content">
			<div class="panel-body text-center">
	        	<div class=" text-center">
	            	<div id="alertMsgForm" class="alert alert-info alert-dismissable hide">
		                <button id="alertCloseForm" aria-hidden="true" class="close" type="button" onclick="form_alert_close()">
		                	<i class="fa fa-times"></i>
		               	</button>
		                <small id="alertTextForm">Data telah disimpan.</small>
		           	</div> 
	            	<div class="col-lg-10" id="loadingmain"> 
			             <img src="<?php echo base_url();?>assets/themes/inspinia/images/724.GIF" class="col-lg-5" >		             
			             <h4 style="color: #333333">Loading, please wait..</h4>
			             &nbsp;&nbsp;<label id="lblprogres">Count blast email.</label>
		            </div> 
	        	</div>
	        </div>
		 </div>
	</div>
</div>
 
