<div id="modal-progress" class="modal fade" aria-hidden="true">
	<div class="modal-dialog"> 
    	<div class="modal-content">
        	<div class="modal-body text-center">
            	<div id="alertMsgForm" class="alert alert-info alert-dismissable hide">
	                <button id="alertCloseForm" aria-hidden="true" class="close" type="button" onclick="form_alert_close()">
	                	<i class="fa fa-times"></i>
	               	</button>
	                <small id="alertTextForm">Data telah disimpan.</small>
	           	</div> 
            	 <div class="progress progress-striped active">
                     <div style="width: 100%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="100" role="progressbar" class="progress-bar progress-bar-info">
	                    <span class="sr-only">100% Complete</span>
	                 </div> 
                 </div>
                 <small>Loading, please wait..</small>  
        	</div>
		</div>
	</div>
</div>
 
